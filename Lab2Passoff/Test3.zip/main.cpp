#include <fstream>
#include "Lexer.h"
using std::cout;
using std::endl;

int main(int argc, char* argv[]) {

    auto* lexer = new Lexer();

    if(argc == 1){
        cout << "No file given as argument" << endl;
        delete lexer;
        return 0;
    }
    std::ostringstream file;
    std::ifstream in(argv[1]);
    std::string line;
    while(!in.eof()){
        std::getline(in, line);
        line.append("\n");
        file << line;
    }
    line = file.str();
    lexer->Run(line);
    cout << *lexer;
    delete lexer;

    return 0;
}